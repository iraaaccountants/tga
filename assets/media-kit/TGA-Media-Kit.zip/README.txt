TGA Manangement Consultancy LLC — Web Media Kit

Included: TGA logo and mark, eight available team portraits, a TGA logo profile graphic used where a portrait has not been supplied, and a clearly labelled team portrait collage.

These are web-resolution WebP files. For print artwork, alternate formats, or permission for a particular publication, contact kintu@tga-uae.com.

Please keep names, roles, logos and photographs accurate and do not alter the brand colours or crop portraits in a misleading way.
Official site: https://www.tga-uae.com/
Brand page: https://www.tga-uae.com/brand.html
