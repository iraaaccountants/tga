TGA Manangement Consultancy LLC — Web Media Kit

Included: TGA primary logo, short mark and two-line company lockup in transparent colour, white and black PNG versions, plus a clearly labelled team portrait collage.

The logos are web-resolution PNG files and the collage is a WebP file. For print artwork, alternate formats, or permission for a particular publication, contact kintu@tga-uae.com.

Please keep names, roles and logos accurate, use the supplied logo colours, and do not use the team collage in a misleading way.
Official site: https://www.tga-uae.com/
Brand page: https://www.tga-uae.com/brand.html
